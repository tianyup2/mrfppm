#include <RcppArmadillo.h>
#include <RcppArmadilloExtensions/sample.h>
// [[Rcpp::depends(RcppArmadillo)]]

using namespace Rcpp;

// [[Rcpp::export]]
arma::mat SEker(arma::mat t, double sigma2c, double sigma2l, double multip){
  // Y is a column matrix
  // assign Y to the i-th column of X
  int len_t=size(t)[0];
  arma::mat ker;
  ker=t*arma::ones(1,len_t);
  ker=arma::exp(-0.5*arma::square(ker-ker.t())/sigma2l);
  ker=sigma2c*(ker+multip*arma::eye(len_t,len_t));
  return(ker);
}

// [[Rcpp::export]]
void columnAssign(int i, NumericMatrix X,arma::mat Y){
  // Y is a column matrix
  // assign Y to the i-th column of X
  int k,n=X.nrow();
  for(k=0;k<n;k++){
    X(k,i)=Y(k);
  }
}

// [[Rcpp::export]]
double log_mvn(arma::mat Y, arma::mat Mu,arma::mat Lambda0){
  // Y and Mu should be column vectors
  double log_lik;
  double d=size(Mu)[0];
  arma::mat std_Y=(Y-Mu).t()*Lambda0*(Y-Mu);
  log_lik= -(d/2)*log(2*arma::datum::pi)+0.5*real(arma::log_det(Lambda0))-0.5*std_Y(0,0);
  return(log_lik);
  
}

// [[Rcpp::export]]
void fn_remove_grid_GP(int n_i, int n, IntegerVector clusterAssign, IntegerVector clusterSize, 
                    IntegerVector nCluster, int nUp,
                    NumericMatrix beta, 
                    NumericVector sigma2c, NumericVector sigma2l, NumericVector multip){
  // n: the number of observations
  // n_i: the observation i
  // nUp: the upper bound of the number of clusters, should be smaller equal to n
  // clusterAssign: the cluster assignment of the n observations, the length should be equal to nUp
  // clusterSize:  the cluster size of each cluster, the length should be equal to nUp
  // beta: a list of distinct beta's, the length should be equal to nUp
  // sigma2c: a list of distinct sigma2c's, the length should be equal to nUp
  // sigma2l: a list of distinct sigma2l's, the length should be equal to nUp+1, with the last value as the value being removed
  // multip: a list of distinct multip's, the length should be equal to nUp+1, same specification
  // Only the first nCluster parameters are valid.
  int cur_clst, i;
  int d=beta.nrow();
  double l2_temp,multip_temp;
  arma::mat ztemp(d,1);
  ztemp.zeros();
  cur_clst = clusterAssign[n_i];// current cluster assignment
  clusterAssign[n_i] = (-1);
  --clusterSize[cur_clst - 1]; //decrease the number of grids by 1 in the corresponding cluster.
  
  //If a grid is clustered by itself
  if (clusterSize[cur_clst - 1] == 0) {
    for (i = 0; i < n; i++) {
      if (clusterAssign[i] > cur_clst ) {
        --clusterAssign[i];
      }
    }
    l2_temp=sigma2l[cur_clst - 1];
    multip_temp=multip[cur_clst - 1];
    for (i = cur_clst; i < nUp; i++) {
      clusterSize[i - 1] = clusterSize[i];
      beta(_,i-1) = beta(_,i);
      sigma2c[i-1] = sigma2c[i];
      sigma2l[i-1] = sigma2l[i];
      multip[i-1] = multip[i];
      
    }
    clusterSize[(nUp - 1)] = 0;
    sigma2c[nUp-1]=0;
    sigma2l[nUp-1] = 0;
    multip[nUp-1] = 0;
    // put the parameter being removed to the end of the lists.
    sigma2l[nUp] = l2_temp;
    multip[nUp] = multip_temp;
    
    columnAssign(nUp-1,beta,ztemp);
    --nCluster[0];
  }
}

// [[Rcpp::export]]
void clusterAssign_update_GP(arma::field<arma::mat> data_y, arma::field<arma::mat> data_x, 
                          arma::field<arma::mat> data_t, arma::mat adj_mat, 
                          int n, IntegerVector nCluster, int nUp, int m,
                          IntegerVector clusterAssign, IntegerVector clusterSize, NumericVector log_vnt,
                          NumericMatrix beta, 
                          NumericVector sigma2c, NumericVector sigma2l, NumericVector multip,
                          double a0, double b0,
                          double a1, double b1,
                          double a2, double b2,
                          arma::mat Mu0, arma::mat Lambda0,
                          double lambda_mrf, double gamma_mfm) {
  // m: using Neal's Algorithm 8, sample m new sigma2l and multip from base measure
  // Using NumericMatrix and NumericVector to pass out the parameter under void function
  // Let another parameter to get each column of beta for convenient operation
  // if use the original conditional cost function, let log_smooth=lambda_mrf*value;
  // suppose l2 and multip from gamma distribution
  NumericVector prob(nUp + m);
  int i, k, len_prob;
  arma::mat y_i, x_i, t_i, Kx, Kxi;
  double len_i;
  arma::mat Mun, Lambdan,mat_temp,beta_temp;
  double an, bn;
  double log_smooth,value;
  IntegerVector range;
  NumericVector tprob;
  IntegerVector ind;
  NumericVector sigma2l_temp;
  NumericVector multip_temp;
  
  for (i = 0; i < n; i++){
    fn_remove_grid_GP(i, n, clusterAssign, clusterSize, nCluster, nUp, beta, sigma2c, sigma2l, multip);
    
    // print(beta);
    // print(sigma2c);
    // print(sigma2l);
    // print(multip);
    // print(clusterAssign);
    // print(clusterSize);
    // Rprintf("%d",nCluster[0]);
    
    std::fill(prob.begin(), prob.end(), 0);
    y_i=data_y(i);
    x_i=data_x(i);
    t_i=data_t(i);
    len_i=size(y_i)[0];
    if(nCluster[0] < nUp){// create a new cluster as usual
      sigma2l_temp=arma::randg(m,arma::distr_param(a1,1/b1));
      multip_temp=arma::randg(m,arma::distr_param(a2,1/b2));
      if(sigma2l[nUp]>0){
        // take value but address
        an=sigma2l[nUp];
        bn=multip[nUp];
        // sample m-1 new samples with the m-th sample equal to the value removed before
        sigma2l_temp[m-1]=an;
        multip_temp[m-1]=bn;
      }
      
      for (k = 0; k < nCluster[0]; k++) {
        value=0;
        for(len_prob=0;len_prob<n;len_prob++){
          if(clusterAssign[len_prob]==(k+1)){
            value=value+adj_mat(i,len_prob);
          }
        }
        log_smooth=lambda_mrf*value;
        Kx=SEker(t_i,sigma2c[k],sigma2l[k],multip[k]);
        Kxi=Kx.i();
        
        beta_temp=beta(_,k);
        mat_temp=(y_i-x_i*beta_temp).t()*Kxi*(y_i-x_i*beta_temp);
        value=-0.5*len_i*log(2*arma::datum::pi)-0.5*real(arma::log_det(Kx))-0.5*mat_temp(0,0);
        prob[k]=log(gamma_mfm+clusterSize[k])+log_smooth+value;
      }
      
      for (k=0; k < m; k++){
        Kx=SEker(t_i,1,sigma2l_temp[k],multip_temp[k]);
        Kxi=Kx.i();
        
        // marginal likelihood of each new sample:
        Lambdan=x_i.t()*Kxi*x_i+Lambda0;
        Mun=Lambdan.i()*(x_i.t()*Kxi*y_i+Lambda0*Mu0);
        
        an=a0+len_i/2;
        bn=b0;
        // bn=0.5*(2*b0+(y_i.t()*y_i)(0,0)+(Mu0.t()*Lambda0*Mu0)(0,0)-(Mun.t()*Lambdan*Mun)(0,0));
        mat_temp=y_i.t()*Kxi*y_i;
        bn=bn+0.5*mat_temp(0,0);
        mat_temp=Mu0.t()*Lambda0*Mu0;
        bn=bn+0.5*mat_temp(0,0);
        mat_temp=Mun.t()*Lambdan*Mun;
        bn=bn-0.5*mat_temp(0,0);
        
        value=-0.5*len_i*log(2*arma::datum::pi)+
          0.5*real(arma::log_det(Lambda0))-0.5*real(arma::log_det(Kx))-0.5*real(arma::log_det(Lambdan))+
          a0*log(b0)-lgamma(a0)+lgamma(an)-an*log(bn);
        
        prob[nCluster[0]+k]=log_vnt[nCluster[0]]-log_vnt[nCluster[0]-1]+log(gamma_mfm)-log(m)+value;// divided by m
      }
      
      // get probability
      range=seq(0,nCluster[0]+m-1);
      tprob=prob[range];
      len_prob=nCluster[0]+m;
      
    }else { // do not create a new cluster
      for (k = 0; k < nCluster[0]; k++) {
        value=0;
        for(len_prob=0;len_prob<n;len_prob++){
          if(clusterAssign[len_prob]==(k+1)){
            value=value+adj_mat(i,len_prob);
          }
        }
        log_smooth=lambda_mrf*value;
        Kx=SEker(t_i,sigma2c[k],sigma2l[k],multip[k]);
        
        beta_temp=beta(_,k);
        mat_temp=(y_i-x_i*beta_temp).t()*Kx.i()*(y_i-x_i*beta_temp);
        value=-0.5*len_i*log(2*arma::datum::pi)-0.5*real(arma::log_det(Kx))-0.5*mat_temp(0,0);
        prob[k]=log(gamma_mfm+clusterSize[k])+log_smooth+value;
      }      
      // get probability
      range=seq(0,nCluster[0]-1);
      tprob=prob[range];
      len_prob=nCluster[0];
    }
    // sample the cluster
    value=max(tprob);
    for (k = 0; k < len_prob; k++) {
      tprob[k]=exp(tprob[k]-value);
    }
    ind=sample(range,1,true,tprob);
    k=ind[0];
    if(k < nCluster[0]){
      ++clusterSize[k];
      clusterAssign[i]=k+1;
    } else {
      clusterSize[nCluster[0]]=1;
      clusterAssign[i]=nCluster[0]+1;
      
      Kx=SEker(t_i,1,sigma2l_temp[k-nCluster[0]],multip_temp[k-nCluster[0]]);
      Kxi=Kx.i();
      
      Lambdan=x_i.t()*Kxi*x_i+Lambda0;
      Mun=Lambdan.i()*(x_i.t()*Kxi*y_i+Lambda0*Mu0);
      an=a0+len_i/2;
      bn=b0;
      // bn=0.5*(2*b0+(y_i.t()*y_i)(0,0)+(Mu0.t()*Lambda0*Mu0)(0,0)-(Mun.t()*Lambdan*Mun)(0,0));
      mat_temp=y_i.t()*Kxi*y_i;
      bn=bn+0.5*mat_temp(0,0);
      mat_temp=Mu0.t()*Lambda0*Mu0;
      bn=bn+0.5*mat_temp(0,0);
      mat_temp=Mun.t()*Lambdan*Mun;
      bn=bn-0.5*mat_temp(0,0);
      
      sigma2c[nCluster[0]]=1/arma::randg(arma::distr_param(an,1/bn));
      sigma2l[nCluster[0]]=sigma2l_temp[k-nCluster[0]];
      multip[nCluster[0]]=multip_temp[k-nCluster[0]];
      beta_temp=mvnrnd(Mun,sigma2c[nCluster[0]]*Lambdan.i());
      
      columnAssign(nCluster[0],beta,beta_temp);
      
      ++nCluster[0];
    }
    
    // set the last value equal to 0:
    sigma2l[nUp] = 0;
    multip[nUp] = 0;
  }
}


// [[Rcpp::export]]
void clusterAssign_update_GP_DP(arma::field<arma::mat> data_y, arma::field<arma::mat> data_x, 
                                arma::field<arma::mat> data_t, arma::mat adj_mat, 
                                int n, IntegerVector nCluster, int nUp, int m,
                                IntegerVector clusterAssign, IntegerVector clusterSize,
                                NumericMatrix beta, 
                                NumericVector sigma2c, NumericVector sigma2l, NumericVector multip,
                                double a0, double b0,
                                double a1, double b1,
                                double a2, double b2,
                                arma::mat Mu0, arma::mat Lambda0,
                                double lambda_mrf, double alpha) {
  // alpha: concentration parameter
  // m: using Neal's Algorithm 8, sample m new sigma2l and multip from base measure
  // Using NumericMatrix and NumericVector to pass out the parameter under void function
  // Let another parameter to get each column of beta for convenient operation
  // if use the original conditional cost function, let log_smooth=lambda_mrf*value;
  // suppose l2 and multip from gamma distribution
  NumericVector prob(nUp + m);
  int i, k, len_prob;
  arma::mat y_i, x_i, t_i, Kx, Kxi;
  double len_i;
  arma::mat Mun, Lambdan,mat_temp,beta_temp;
  double an, bn;
  double log_smooth,value;
  IntegerVector range;
  NumericVector tprob;
  IntegerVector ind;
  NumericVector sigma2l_temp;
  NumericVector multip_temp;
  
  for (i = 0; i < n; i++){
    fn_remove_grid_GP(i, n, clusterAssign, clusterSize, nCluster, nUp, beta, sigma2c, sigma2l, multip);
    
    // print(beta);
    // print(sigma2c);
    // print(sigma2l);
    // print(multip);
    // print(clusterAssign);
    // print(clusterSize);
    // Rprintf("%d",nCluster[0]);
    
    std::fill(prob.begin(), prob.end(), 0);
    y_i=data_y(i);
    x_i=data_x(i);
    t_i=data_t(i);
    len_i=size(y_i)[0];
    if(nCluster[0] < nUp){// create a new cluster as usual
      sigma2l_temp=arma::randg(m,arma::distr_param(a1,1/b1));
      multip_temp=arma::randg(m,arma::distr_param(a2,1/b2));
      if(sigma2l[nUp]>0){
        // take value but address
        an=sigma2l[nUp];
        bn=multip[nUp];
        // sample m-1 new samples with the m-th sample equal to the value removed before
        sigma2l_temp[m-1]=an;
        multip_temp[m-1]=bn;
      }
      
      for (k = 0; k < nCluster[0]; k++) {
        value=0;
        for(len_prob=0;len_prob<n;len_prob++){
          if(clusterAssign[len_prob]==(k+1)){
            value=value+adj_mat(i,len_prob);
          }
        }
        log_smooth=lambda_mrf*value;
        Kx=SEker(t_i,sigma2c[k],sigma2l[k],multip[k]);
        Kxi=Kx.i();
        
        beta_temp=beta(_,k);
        mat_temp=(y_i-x_i*beta_temp).t()*Kxi*(y_i-x_i*beta_temp);
        value=-0.5*len_i*log(2*arma::datum::pi)-0.5*real(arma::log_det(Kx))-0.5*mat_temp(0,0);
        prob[k]=log(clusterSize[k])+log_smooth+value;
      }
      
      for (k=0; k < m; k++){
        Kx=SEker(t_i,1,sigma2l_temp[k],multip_temp[k]);
        Kxi=Kx.i();
        
        // marginal likelihood of each new sample:
        Lambdan=x_i.t()*Kxi*x_i+Lambda0;
        Mun=Lambdan.i()*(x_i.t()*Kxi*y_i+Lambda0*Mu0);
        
        an=a0+len_i/2;
        bn=b0;
        // bn=0.5*(2*b0+(y_i.t()*y_i)(0,0)+(Mu0.t()*Lambda0*Mu0)(0,0)-(Mun.t()*Lambdan*Mun)(0,0));
        mat_temp=y_i.t()*Kxi*y_i;
        bn=bn+0.5*mat_temp(0,0);
        mat_temp=Mu0.t()*Lambda0*Mu0;
        bn=bn+0.5*mat_temp(0,0);
        mat_temp=Mun.t()*Lambdan*Mun;
        bn=bn-0.5*mat_temp(0,0);
        
        value=-0.5*len_i*log(2*arma::datum::pi)+
          0.5*real(arma::log_det(Lambda0))-0.5*real(arma::log_det(Kx))-0.5*real(arma::log_det(Lambdan))+
          a0*log(b0)-lgamma(a0)+lgamma(an)-an*log(bn);
        
        prob[nCluster[0]+k]=log(alpha)-log(m)+value;// divided by m
      }
      
      // get probability
      range=seq(0,nCluster[0]+m-1);
      tprob=prob[range];
      len_prob=nCluster[0]+m;
      
    }else { // do not create a new cluster
      for (k = 0; k < nCluster[0]; k++) {
        value=0;
        for(len_prob=0;len_prob<n;len_prob++){
          if(clusterAssign[len_prob]==(k+1)){
            value=value+adj_mat(i,len_prob);
          }
        }
        log_smooth=lambda_mrf*value;
        Kx=SEker(t_i,sigma2c[k],sigma2l[k],multip[k]);
        
        beta_temp=beta(_,k);
        mat_temp=(y_i-x_i*beta_temp).t()*Kx.i()*(y_i-x_i*beta_temp);
        value=-0.5*len_i*log(2*arma::datum::pi)-0.5*real(arma::log_det(Kx))-0.5*mat_temp(0,0);
        prob[k]=log(clusterSize[k])+log_smooth+value;
      }      
      // get probability
      range=seq(0,nCluster[0]-1);
      tprob=prob[range];
      len_prob=nCluster[0];
    }
    // sample the cluster
    value=max(tprob);
    for (k = 0; k < len_prob; k++) {
      tprob[k]=exp(tprob[k]-value);
    }
    ind=sample(range,1,true,tprob);
    k=ind[0];
    if(k < nCluster[0]){
      ++clusterSize[k];
      clusterAssign[i]=k+1;
    } else {
      clusterSize[nCluster[0]]=1;
      clusterAssign[i]=nCluster[0]+1;
      
      Kx=SEker(t_i,1,sigma2l_temp[k-nCluster[0]],multip_temp[k-nCluster[0]]);
      Kxi=Kx.i();
      
      Lambdan=x_i.t()*Kxi*x_i+Lambda0;
      Mun=Lambdan.i()*(x_i.t()*Kxi*y_i+Lambda0*Mu0);
      an=a0+len_i/2;
      bn=b0;
      // bn=0.5*(2*b0+(y_i.t()*y_i)(0,0)+(Mu0.t()*Lambda0*Mu0)(0,0)-(Mun.t()*Lambdan*Mun)(0,0));
      mat_temp=y_i.t()*Kxi*y_i;
      bn=bn+0.5*mat_temp(0,0);
      mat_temp=Mu0.t()*Lambda0*Mu0;
      bn=bn+0.5*mat_temp(0,0);
      mat_temp=Mun.t()*Lambdan*Mun;
      bn=bn-0.5*mat_temp(0,0);
      
      sigma2c[nCluster[0]]=1/arma::randg(arma::distr_param(an,1/bn));
      sigma2l[nCluster[0]]=sigma2l_temp[k-nCluster[0]];
      multip[nCluster[0]]=multip_temp[k-nCluster[0]];
      beta_temp=mvnrnd(Mun,sigma2c[nCluster[0]]*Lambdan.i());
      
      columnAssign(nCluster[0],beta,beta_temp);
      
      ++nCluster[0];
    }
    
    // set the last value equal to 0:
    sigma2l[nUp] = 0;
    multip[nUp] = 0;
  }
}

// [[Rcpp::export]]
void clusterParameter_update_GP(arma::field<arma::mat> data_y, arma::field<arma::mat> data_x,arma::field<arma::mat> data_t,
                             int n, int n_rep, double mh_st,
                             IntegerVector nCluster, IntegerVector clusterAssign,
                             NumericMatrix beta, 
                             NumericVector sigma2c, NumericVector sigma2l, NumericVector multip,
                             double a0, double b0,
                             double a1, double b1,
                             double a2, double b2,
                             arma::mat Mu0, arma::mat Lambda0) {
  
  int i, k, idx, i_rep;
  arma::mat y_i, x_i, t_i, Kx, Kxi;
  double len_i;
  arma::mat mat_temp,beta_temp;
  
  NumericVector sigma2l_new, multip_new;
  NumericVector log_Lik_old(nCluster[0]), log_Lik_new(nCluster[0]);
  double value, sigma2l_temp, multip_temp;
  NumericVector an_list(nCluster[0]);
  NumericVector bn_list(nCluster[0]);
  arma::field<arma::mat> Mun_list(nCluster[0]);
  arma::field<arma::mat> Lambdan_list(nCluster[0]);
  
  for (i_rep=0;i_rep<n_rep;i_rep++){
    // Initialize
    for (k = 0; k < nCluster[0]; k++){
      an_list[k]=a0;
      bn_list[k]=b0;
      Mun_list(k)=Mu0;
      Lambdan_list(k)=Lambda0;
      log_Lik_old[k]=0;
      log_Lik_new[k]=0;
    }
    
    for (i = 0; i < n; i++){
      y_i=data_y(i);
      x_i=data_x(i);
      t_i=data_t(i);
      len_i=size(y_i)[0];
      
      idx=clusterAssign[i]-1;
      Kx=SEker(t_i,1,sigma2l[idx],multip[idx]);
      Kxi=Kx.i();
        
      // bn=0.5*(2*b0+(y_i.t()*y_i)(0,0)+(Mu0.t()*Lambda0*Mu0)(0,0)-(Mun.t()*Lambdan*Mun)(0,0));
      an_list[idx]=an_list[idx]+len_i/2;
      mat_temp=y_i.t()*Kxi*y_i;
      bn_list[idx]=bn_list[idx]+0.5*mat_temp(0,0);
      // mu_old'*Lambda_old*mu_old
      mat_temp=Mun_list(idx).t()*Lambdan_list(idx)*Mun_list(idx);
      bn_list[idx]=bn_list[idx]+0.5*mat_temp(0,0);
      // update mu and lambda
      mat_temp=Lambdan_list(idx)*Mun_list(idx);// get Lambda_old*mu_old
      Lambdan_list(idx)=x_i.t()*Kxi*x_i+Lambdan_list(idx);
      Mun_list(idx)=Lambdan_list(idx).i()*(x_i.t()*Kxi*y_i+mat_temp);
      // mu_new'*Lambda_new*mu_new
      mat_temp=Mun_list(idx).t()*Lambdan_list(idx)*Mun_list(idx);
      bn_list[idx]=bn_list[idx]-0.5*mat_temp(0,0);
    }
    
    // update beta and sigma2:
    sigma2l_new=rnorm(nCluster[0],0,mh_st);
    multip_new=rnorm(nCluster[0],0,mh_st);
    for (k = 0; k < nCluster[0]; k++){
      // Rprintf("k: %d, an:%f, bn:%f",k+1,an_list[k],1/bn_list[k]);
      sigma2c[k]=1/arma::randg(arma::distr_param(an_list[k],1/bn_list[k]));
      beta_temp=mvnrnd(Mun_list(k),sigma2c[k]*Lambdan_list(k).i());
      columnAssign(k,beta,beta_temp);
      if(sigma2l_new[k]+sigma2l[k]>0){
        sigma2l_new[k]=sigma2l_new[k]+sigma2l[k];
      }else{
        sigma2l_new[k]=1e-4;
      }
      
      if(multip_new[k]+multip[k]>0){
        multip_new[k]=multip_new[k]+multip[k];
      }else{
        multip_new[k]=1e-4;
      }
    }
    // update sigma2l:
    for (i = 0; i < n; i++){
      y_i=data_y(i);
      x_i=data_x(i);
      t_i=data_t(i);
      len_i=size(y_i)[0];
      
      idx=clusterAssign[i]-1;
      sigma2l_temp=sigma2l_new[idx];
      
      beta_temp=beta(_,idx);
      
      Kx=SEker(t_i,sigma2c[idx],sigma2l[idx],multip[idx]);
      Kxi=Kx.i();
      
      mat_temp=(y_i-x_i*beta_temp).t()*Kxi*(y_i-x_i*beta_temp);
      value=-0.5*len_i*log(2*arma::datum::pi)-0.5*real(arma::log_det(Kx))-0.5*mat_temp(0,0);
      log_Lik_old[idx]=log_Lik_old[idx]+value;
      
      Kx=SEker(t_i,sigma2c[idx],sigma2l_temp,multip[idx]);
      Kxi=Kx.i();
      
      mat_temp=(y_i-x_i*beta_temp).t()*Kxi*(y_i-x_i*beta_temp);
      value=-0.5*len_i*log(2*arma::datum::pi)-0.5*real(arma::log_det(Kx))-0.5*mat_temp(0,0);
      log_Lik_new[idx]=log_Lik_new[idx]+value;
    }
    
    for (k = 0; k < nCluster[0]; k++){
      log_Lik_old[k]=log_Lik_old[k]+R::dgamma(sigma2l[k],a1,1/b1,1);
      sigma2l_temp=sigma2l_new[k];
      log_Lik_new[k]=log_Lik_new[k]+R::dgamma(sigma2l_temp,a1,1/b1,1);
      if (log(R::runif(0,1)) < (log_Lik_new[k]-log_Lik_old[k])){
        sigma2l[k]=sigma2l_temp;
      }
      // initialize for the next Mh
      log_Lik_old[k]=0;
      log_Lik_new[k]=0;
    }
    // update multip:
    for (i = 0; i < n; i++){
      y_i=data_y(i);
      x_i=data_x(i);
      t_i=data_t(i);
      len_i=size(y_i)[0];
      
      idx=clusterAssign[i]-1;
      multip_temp=multip_new[idx];
      
      beta_temp=beta(_,idx);
      
      Kx=SEker(t_i,sigma2c[idx],sigma2l[idx],multip[idx]);
      Kxi=Kx.i();
      
      mat_temp=(y_i-x_i*beta_temp).t()*Kxi*(y_i-x_i*beta_temp);
      value=-0.5*len_i*log(2*arma::datum::pi)-0.5*real(arma::log_det(Kx))-0.5*mat_temp(0,0);
      log_Lik_old[idx]=log_Lik_old[idx]+value;
      
      Kx=SEker(t_i,sigma2c[idx],sigma2l[idx],multip_temp);
      Kxi=Kx.i();
      
      mat_temp=(y_i-x_i*beta_temp).t()*Kxi*(y_i-x_i*beta_temp);
      value=-0.5*len_i*log(2*arma::datum::pi)-0.5*real(arma::log_det(Kx))-0.5*mat_temp(0,0);
      log_Lik_new[idx]=log_Lik_new[idx]+value;
    }
    
    for (k = 0; k < nCluster[0]; k++){
      log_Lik_old[k]=log_Lik_old[k]+R::dgamma(multip[k],a2,1/b2,1);
      multip_temp=multip_new[k];
      log_Lik_new[k]=log_Lik_new[k]+R::dgamma(multip_temp,a2,1/b2,1);
      if (log(R::runif(0,1)) < (log_Lik_new[k]-log_Lik_old[k])){
        multip[k]=multip_temp;
      }
    }
    // print(beta);
    // print(sigma2c);
    // print(sigma2l);
    // print(multip);
    // print(clusterAssign);
    // Rprintf("%d",nCluster[0]);
  }
}

// [[Rcpp::export]]
void ml_mrf_mfm_GP(int n_burn, int n_i, NumericVector ml_max, NumericVector log_ml_list,
                  arma::field<arma::mat> data_y, arma::field<arma::mat> data_x, 
                  arma::field<arma::mat> data_t, arma::mat adj_mat, 
                  int n, int nUp, IntegerVector nCluster,
                  IntegerVector clusterAssign, IntegerVector clusterSize, NumericVector log_vnt,
                  double a0, double b0, double a1, double b1, double a2, double b2,
                  arma::mat Mu0, arma::mat Lambda0, double lambda_mrf, double gamma_mfm) {
  // log_ml_list[0]: current ml; log_ml_list[1]: accumulated ml;
  NumericVector prob(nUp + 0L, 0);
  int i, k, len_prob,len_i;
  int cur_clst, idx;
  arma::mat y_i, x_i, t_i, Kx, Kxi;
  double value, log_smooth;
  arma::mat mat_temp;
  IntegerVector range;
  NumericVector tprob;
  IntegerVector ind;
  
  NumericVector sigma2l_list(nUp);
  NumericVector multip_list(nUp);
  NumericVector an_list(nUp);
  NumericVector bn_list(nUp);
  NumericVector ks_list(nUp);
  NumericVector Kx_det_list(nUp);
  arma::field<arma::mat> Mun_list(nUp);
  arma::field<arma::mat> Lambdan_list(nUp);
  
  sigma2l_list=arma::randg(nUp,arma::distr_param(a1,1/b1));
  multip_list=arma::randg(nUp,arma::distr_param(a2,1/b2));

  for (k = 0; k < nUp; k++){
    an_list[k]=a0;
    bn_list[k]=b0;
    ks_list[k]=0;
    Kx_det_list[k]=0;
    Mun_list(k)=Mu0;
    Lambdan_list(k)=Lambda0;
  }
  log_ml_list[0]=0;
  for (i = 0; i < n; i++){
    
    cur_clst = clusterAssign[i];// current cluster assignment
    clusterAssign[i] = (-1);
    --clusterSize[cur_clst - 1]; //decrease the number of grids by 1 in the corresponding cluster.
    
    //If a grid is clustered by itself
    if (clusterSize[cur_clst - 1] == 0) {
      for (idx = 0; idx < n; idx++) {
        if (clusterAssign[idx] > cur_clst ) {
          --clusterAssign[idx];
        }
      }
      for (idx = cur_clst; idx < nUp; idx++) {
        clusterSize[idx - 1] = clusterSize[idx];
        an_list[idx-1]=an_list[idx];
        bn_list[idx-1]=bn_list[idx];
        ks_list[idx-1]=ks_list[idx];
        Mun_list(idx-1)=Mun_list(idx);
        Lambdan_list(idx-1)=Lambdan_list(idx);
      }
      clusterSize[(nUp - 1)] = 0;
      an_list[(nUp - 1)]=a0;
      bn_list[(nUp - 1)]=b0;
      ks_list[(nUp - 1)]=0;
      Mun_list((nUp - 1))=Mu0;
      Lambdan_list((nUp - 1))=Lambda0;
      --nCluster[0];
    }
    
    std::fill(prob.begin(), prob.end(), 0);
    y_i=data_y(i);
    x_i=data_x(i);
    t_i=data_t(i);
    len_i=size(y_i)[0];
    
    if(nCluster[0] < nUp){// create a new cluster as usual
      for (k = 0; k < nCluster[0]; k++) {
        value=0;
        for(len_prob=0;len_prob<n;len_prob++){
          if(clusterAssign[len_prob]==(k+1)){
            value=value+adj_mat(i,len_prob);
          }
        }
        log_smooth=lambda_mrf*value;
        prob[k]=log(gamma_mfm+clusterSize[k])+log_smooth;
      }

      prob[nCluster[0]]=log_vnt[nCluster[0]]-log_vnt[nCluster[0]-1]+log(gamma_mfm);
      // get probability
      range=seq(0,nCluster[0]);
      tprob=prob[range];
      len_prob=nCluster[0]+1;
      
    }else { // do not create a new cluster
      for (k = 0; k < nCluster[0]; k++) {
        value=0;
        for(len_prob=0;len_prob<n;len_prob++){
          if(clusterAssign[len_prob]==(k+1)){
            value=value+adj_mat(i,len_prob);
          }
        }
        log_smooth=lambda_mrf*value*nCluster[0];
        prob[k]=log(gamma_mfm+clusterSize[k])+log_smooth;
      }      
      // get probability
      range=seq(0,nCluster[0]-1);
      tprob=prob[range];
      len_prob=nCluster[0];
    }
    // sample the cluster
    value=max(tprob);
    for (k = 0; k < len_prob; k++) {
      tprob[k]=exp(tprob[k]-value);
    }
    ind=sample(range,1,true,tprob);
    k=ind[0];
    clusterAssign[i]=k+1;
    if(k < nCluster[0]){
      ++clusterSize[k];
    } else {
      clusterSize[k]=1;
      ++nCluster[0];
    }

    Kx=SEker(t_i,1,sigma2l_list[k],multip_list[k]);
    Kxi=Kx.i();
    
    an_list[k]=an_list[k]+len_i/2;
    mat_temp=y_i.t()*Kxi*y_i;
    bn_list[k]=bn_list[k]+0.5*mat_temp(0,0);
    // mu_old'*Lambda_old*mu_old
    mat_temp=Mun_list(k).t()*Lambdan_list(k)*Mun_list(k);
    bn_list[k]=bn_list[k]+0.5*mat_temp(0,0);
    // update mu and lambda
    mat_temp=Lambdan_list(k)*Mun_list(k);// get Lambda_old*mu_old
    Lambdan_list(k)=x_i.t()*Kxi*x_i+Lambdan_list(k);
    Mun_list(k)=Lambdan_list(k).i()*(x_i.t()*Kxi*y_i+mat_temp);
    // mu_new'*Lambda_new*mu_new
    mat_temp=Mun_list(k).t()*Lambdan_list(k)*Mun_list(k);
    bn_list[k]=bn_list[k]-0.5*mat_temp(0,0);
    ks_list[k]=ks_list[k]+len_i;
    Kx_det_list[k]=Kx_det_list[k]+real(arma::log_det(Kx));
    
    //Rprintf("k:%d,an:%f,bn:%f:,ks:%f,nClust:%d",k,an_list[k],bn_list[k],ks_list[k],nCluster[0]);
    //Mun_list(k).print();
    //Lambdan_list(k).print();
    //print(clusterAssign);
  }
  
  for(i=0;i < nCluster[0]; i++){
    value=-0.5*ks_list[i]*log(2*arma::datum::pi)-0.5*Kx_det_list[i]+0.5*real(arma::log_det(Lambda0))-0.5*real(arma::log_det(Lambdan_list(i)))+
      a0*log(b0)-lgamma(a0)+lgamma(an_list[i])-an_list[i]*log(bn_list[i]);
    //Rprintf("ml_part: %f \n",value);
    log_ml_list[0]=log_ml_list[0]+value;
  }
  //Rprintf("ml: %f,",log_ml_list[0]);
  
  if(n_i>=n_burn){
    if(log_ml_list[0]>ml_max[0]){
      ml_max[0]=log_ml_list[0];
    }
    
    log_ml_list[1]=log(exp(log_ml_list[1] - ml_max[0]) + 
      exp(log_ml_list[0] - ml_max[0])) + ml_max[0];
  }
  
}
